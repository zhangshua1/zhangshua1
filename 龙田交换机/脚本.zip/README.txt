1、安装python3.8运行环境
pip install netmiko
pip install xlwt
pip install xlrd
pip install xlutils
2、修改脚本中交换机用户名、密码
3、脚本运行生成的Excel文件在当前目录
4、将设备列表IP写在switchlist文件中
